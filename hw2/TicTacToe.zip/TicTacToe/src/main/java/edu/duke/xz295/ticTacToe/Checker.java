package edu.duke.xz295.ticTacToe;

public interface Checker {
    Boolean check();
}
